"""
    Name: eval_and_extract_wav2vec.py

    Description: Script to extract wav2vec embeddings from the model's
                 last hidden layer and store these embeddings as npy
"""

from transformers import Wav2Vec2ForCTC, Wav2Vec2Processor
from datasets import load_dataset
import soundfile as sf
import torch
import torchaudio
import sys, os
import numpy as np
from spectrogram_helpers import get_spec

use_cuda = torch.cuda.is_available()
device = torch.device('cuda:0' if use_cuda else 'cpu')
print("Device: ", device)

MODEL_TYPE = "facebook/wav2vec2-large-lv60"

processor = Wav2Vec2Processor.from_pretrained(MODEL_TYPE)
model = Wav2Vec2ForCTC.from_pretrained(MODEL_TYPE)

# model to cuda
model = model.to(device)
speech_file="E:/data/SER/RAVDESS/Actor_01/03-01-03-01-01-01-01.wav"
waveform, sample_rate = torchaudio.load(speech_file)
speech, _ = sf.read(speech_file)
print(speech.shape)

# define padding to match the spectrograms
# if(len(speech)%320 >= 80):
#     padding = 160
# else:
#     pading = 319
#
# speech = np.pad(speech, padding, mode='constant')
# print(len(speech))
#
#
# # get the spectrogram and compare the shape of the spectrogram and the
# # shape of the wav2vec features
# spec = get_spec(speech_file)
# print(spec.shape)

inputs = processor(speech, return_tensors="pt", sampling_rate=16000, padding=True)
input_values = inputs.input_values.to(device)
attention_mask = inputs.attention_mask.to(device)


# we run the model in inference mode just to get the output
with torch.no_grad():
    output = model(input_values, attention_mask=attention_mask, output_hidden_states=True)

hidden_states=output.hidden_states
audio_input=hidden_states[-1].squeeze()

print("features: ", hidden_states[-1].detach().cpu().numpy().squeeze().shape)






